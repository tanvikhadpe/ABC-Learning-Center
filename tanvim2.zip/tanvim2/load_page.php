<?php

	if(!$_POST['page']) 
		die("0");

	$page = $_POST['page'];

	if(file_exists('mypages/'.$page.'.html'))
		echo file_get_contents('mypages/'.$page.'.html');

	else echo 'There is no such page!'.$page;
?>
