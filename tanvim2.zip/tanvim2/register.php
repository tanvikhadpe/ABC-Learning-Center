<?php

$con = $con=mysqli_connect("projects.lithan.net","INC0208","INC0208","inc0208");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$age=$_POST['age'];
$phone=$_POST['phone'];
$email = filter_var($email, FILTER_SANITIZE_EMAIL); 
$result = mysqli_query($con,"INSERT INTO leadgen(fname,lname, email, age, phone)
 values ('$fname','$lname', '$email','$age','$phone')");

if($result){
mysqli_close ($con); 
}
?>